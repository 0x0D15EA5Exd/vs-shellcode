#include <Windows.h>

#include "ntdll.h"
#include "hash.h"
#include "macro.h"


#pragma code_seg(".text$b")
void* xGetModuleAddr(DWORD dwModuleHash)
{
	PTEB pCurrentTeb = (PTEB)__readgsqword(0x30);
	PPEB pCurrentPeb = pCurrentTeb->ProcessEnvironmentBlock;
	PVOID pLdrDataEntryFirstEntry = (PVOID)((PBYTE)pCurrentPeb->Ldr->InMemoryOrderModuleList.Flink->Flink);

	LIST_ENTRY* pListParser = (LIST_ENTRY*)((DWORD64)pLdrDataEntryFirstEntry - 0x10);
	void* firstEntry = pListParser;
	while (pListParser->Flink != pLdrDataEntryFirstEntry)
	{
		PLDR_DATA_TABLE_ENTRY pLdrDataEntry = (PLDR_DATA_TABLE_ENTRY)pListParser->Blink;
		if (HashMeDjb2W(pLdrDataEntry->BaseDllName.Buffer) == dwModuleHash)
		{
			return pLdrDataEntry->DllBase;
		}

		if (pListParser->Flink == firstEntry)
		{
			return NULL;
		}
		pListParser = pListParser->Flink;
	}
	return NULL;
}

#pragma code_seg(".text$b")
void* xGetProcAddr(void* pModuleAddr, DWORD dwFunctionHash)
{
	PIMAGE_DOS_HEADER pImageDosHeader = (PIMAGE_DOS_HEADER)pModuleAddr;
	PIMAGE_NT_HEADERS pImageNtHeaders = (PIMAGE_NT_HEADERS)((PBYTE)pModuleAddr + pImageDosHeader->e_lfanew);
	PIMAGE_EXPORT_DIRECTORY pImgExportDir = (PIMAGE_EXPORT_DIRECTORY)((PBYTE)pModuleAddr + pImageNtHeaders->OptionalHeader.DataDirectory[0].VirtualAddress);

	PDWORD pdwAddressOfFunctions = (PDWORD)((PBYTE)pModuleAddr + pImgExportDir->AddressOfFunctions);
	PDWORD pdwAddressOfNames = (PDWORD)((PBYTE)pModuleAddr + pImgExportDir->AddressOfNames);
	PWORD pwAddressOfNameOrdinales = (PWORD)((PBYTE)pModuleAddr + pImgExportDir->AddressOfNameOrdinals);

	for (WORD i = 0; i < pImgExportDir->NumberOfNames; i++)
	{
		PCHAR pczFunctionName = (PCHAR)((PBYTE)pModuleAddr + pdwAddressOfNames[i]);
		if (HashMeDjb2A(pczFunctionName) == dwFunctionHash)
		{
			return (PBYTE)pModuleAddr + pdwAddressOfFunctions[pwAddressOfNameOrdinales[i]];
		}
	}

	return NULL;
}

typedef int		(WINAPI* VSPRINTF_S)	(char*, size_t, const char*, va_list);
typedef BOOL	(WINAPI* WRITECONSOLEA)	(HANDLE, const void*, DWORD, LPDWORD, LPVOID);
typedef HANDLE	(WINAPI* GETSTDHANDLE)	(DWORD);

#pragma code_seg(".text$b")
void myPrintf(const char* format, ...) {

	void* pKernel32 =	xGetModuleAddr(KERNEL32_HASH);
	void* pNtdll =		xGetModuleAddr(NTDLL_HASH);

	VSPRINTF_S pvsprintf_s =		(VSPRINTF_S)xGetProcAddr(pNtdll, VSPRINTF_S_HASH);
	WRITECONSOLEA pWriteConsoleA =	(WRITECONSOLEA)xGetProcAddr(pKernel32, WRITECONSOLEA_HASH);
	GETSTDHANDLE pGetStdHandle =	(GETSTDHANDLE)xGetProcAddr(pKernel32, GETSTDHANDLE_HASH);

	HANDLE consoleHandle = pGetStdHandle(STD_OUTPUT_HANDLE);
	va_list args;
	va_start(args, format);

	const int bufferSize = 512;
	char buffer[bufferSize];
	int result = pvsprintf_s(buffer, bufferSize, format, args);

	va_end(args);

	DWORD charsWritten;
	pWriteConsoleA(consoleHandle, buffer, result, &charsWritten, NULL);
}


