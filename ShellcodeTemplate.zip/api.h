#include <Windows.h>

void* xGetProcAddr(void* pModuleAddr, DWORD dwFunctionHash);
void* xGetModuleAddr(DWORD dwModuleHash);
void myPrintf(const char* format, ...);