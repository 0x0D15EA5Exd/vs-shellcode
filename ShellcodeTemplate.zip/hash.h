#include <Windows.h>

DWORD HashMeDjb2W(wchar_t* str);
DWORD HashMeDjb2A(char* str);


constexpr DWORD CompileHashMeDjb2W(const wchar_t* str)
{
	DWORD hash = 5381;
	int c = 0;

	while ((c = *str++)) {
		if (c >= 'A' && c <= 'Z') {
			c += ('a' - 'A');
		}
		hash = ((hash << 5) + hash) + c;
	}
	return hash;
}

constexpr DWORD CompileHashMeDjb2A(const char* str)
{
	DWORD hash = 5381;
	int c = 0;

	while ((c = *str++)) {
		if (c >= 'A' && c <= 'Z') {
			c += ('a' - 'A');
		}
		hash = ((hash << 5) + hash) + c;
	}
	return hash;
}



constexpr DWORD KERNEL32_HASH = CompileHashMeDjb2W(L"kernel32.dll");
constexpr DWORD NTDLL_HASH = CompileHashMeDjb2W(L"ntdll.dll");

constexpr DWORD LOADLIBRARYA_HASH = CompileHashMeDjb2A("LoadLibraryA");
constexpr DWORD MESSAGEBOXA_HASH = CompileHashMeDjb2A("MessageBoxA");

constexpr DWORD WRITECONSOLEA_HASH = CompileHashMeDjb2A("WriteConsoleA");
constexpr DWORD GETSTDHANDLE_HASH = CompileHashMeDjb2A("GetStdHandle");
constexpr DWORD VSPRINTF_S_HASH = CompileHashMeDjb2A("vsprintf_s");