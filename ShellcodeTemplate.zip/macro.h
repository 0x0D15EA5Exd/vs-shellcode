#pragma section(".text", execute, readwrite)
#pragma section(".rdata", read, reads)
#pragma code_seg(".text$d")
#define DECLARE_BYTE_ARRAY_IN_TEXT_D(name, data) \
    __declspec(allocate(".text$d")) static BYTE name[] = data

#define MACRO_STR(bufferName, data) DECLARE_BYTE_ARRAY_IN_TEXT_D(bufferName, data)


