/* ------------------------------------------ -
    ShellcodeTemplate by DallasFR

    Visual Studio Template to easly made shellcode.

    Feature :
    - All API Call is dynamicly solved with API Hashing (djb2), easy to edit with compile time hashing
    - You can use variable, the .rdata section is merged at the end of .text section, easy to use with macro
    - Implementation of printf for easy debugging

------------------------------------------- */

#include <Windows.h>

#include "ntdll.h"
#include "hash.h"
#include "api.h"
#include "macro.h"


typedef HMODULE     (WINAPI* LOADLIBRARYA)      (LPCSTR);
typedef int         (WINAPI* MESSAGEBOXA)       (HWND, LPCSTR, LPCSTR, UINT);

#pragma code_seg(".text$a")
int EntryPoint() {

	MACRO_STR(myBuffer, "Hello World !");
    MACRO_STR(bUser32, "User32.dll");

	myPrintf((const char*)myBuffer);

    void* pKernel32 = xGetModuleAddr(KERNEL32_HASH);
    LOADLIBRARYA fnLoadLibraryA = (LOADLIBRARYA)xGetProcAddr(pKernel32, LOADLIBRARYA_HASH);

    void* pUser32 = fnLoadLibraryA((LPCSTR)bUser32);
    MESSAGEBOXA fnMessageBoxA = (MESSAGEBOXA)xGetProcAddr(pUser32, MESSAGEBOXA_HASH);

    fnMessageBoxA(NULL, (LPCSTR)myBuffer, (LPCSTR)myBuffer, MB_OK);

	return EXIT_SUCCESS;
}